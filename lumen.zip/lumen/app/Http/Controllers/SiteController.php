<?php

namespace App\Http\Controllers;

use App\Site;

class SiteController extends Controller
{

    public function read($id)
    {

    }

    public function create
    {

    }

    public function update($id)
    {

    }

    public function delete($id)
    {

    }


}
